# Portal de Admisiones y Registro Académico - UAM

Este proyecto integra:

- 🌐 Un sitio web futurista monocromático.
- 🤖 Un agente virtual (Botpress).
- 📚 Un portal de guías de inducción.
- ✅ Un gestor de tareas.

**Diseño basado en la identidad de la Universidad Autónoma de Manizales (UAM).**

---

## Publicación en GitHub Pages
Este `index.html` está listo para ser publicado en GitHub Pages. 
Sólo debes ir a tu repositorio > Settings > Pages y seleccionar la rama principal (/root).
